package com.rahim.apkcmd

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Ver(val n: Int, val label: String, val file: String, val time: Long)

class Project(val dir: File) {
    var name = ""
    var kind = "apk"
    val versions = mutableListOf<Ver>()

    fun latest() = versions.last()
    fun fileOf(v: Ver) = File(dir, v.file)

    fun save() {
        val arr = JSONArray()
        versions.forEach {
            arr.put(JSONObject().put("n", it.n).put("label", it.label).put("file", it.file).put("time", it.time))
        }
        File(dir, "meta.json").writeText(
            JSONObject().put("name", name).put("kind", kind).put("versions", arr).toString()
        )
    }

    companion object {
        fun create(root: File, name: String, kind: String): Project {
            val d = File(root, System.currentTimeMillis().toString()).apply { mkdirs() }
            return Project(d).also { it.name = name; it.kind = kind }
        }

        fun load(dir: File): Project? = try {
            val j = JSONObject(File(dir, "meta.json").readText())
            Project(dir).also { p ->
                p.name = j.getString("name"); p.kind = j.getString("kind")
                val arr = j.getJSONArray("versions")
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    p.versions += Ver(o.getInt("n"), o.getString("label"), o.getString("file"), o.getLong("time"))
                }
                if (p.versions.isEmpty()) return null
            }
        } catch (e: Exception) { null }
    }
}

object Store {
    fun root(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "projects").apply { mkdirs() }

    /** حذف المشاريع الأقدم من [days] يومًا (الخصوصية) */
    fun cleanup(ctx: Context, days: Int = 30) {
        val limit = System.currentTimeMillis() - days * 86_400_000L
        root(ctx).listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }
    }

    fun last(ctx: Context): Project? =
        root(ctx).listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.name }
            ?.firstNotNullOfOrNull { Project.load(it) }
}
