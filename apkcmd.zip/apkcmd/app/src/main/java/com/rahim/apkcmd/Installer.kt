package com.rahim.apkcmd

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import java.io.File
import java.util.zip.ZipFile

class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val it: Intent? = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                else i.getParcelableExtra(Intent.EXTRA_INTENT)
                it?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { x -> c.startActivity(x) }
            }
            PackageInstaller.STATUS_SUCCESS -> Toast.makeText(c, "تم التثبيت ✅", Toast.LENGTH_LONG).show()
            else -> Toast.makeText(c, "فشل التثبيت: " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE), Toast.LENGTH_LONG).show()
        }
    }
}

object Installer {
    fun install(ctx: Context, f: File, kind: String) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Toast.makeText(ctx, "فعّل السماح بالتثبيت لهذا التطبيق ثم اضغط تثبيت مرة أخرى", Toast.LENGTH_LONG).show()
            return
        }
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            if (kind == "apks") {
                ZipFile(f).use { zf ->
                    zf.entries().asSequence().filter { it.name.endsWith(".apk") }.forEachIndexed { i, e ->
                        s.openWrite("p$i.apk", 0, e.size).use { o ->
                            zf.getInputStream(e).use { it.copyTo(o) }; s.fsync(o)
                        }
                    }
                }
            } else {
                s.openWrite("base.apk", 0, f.length()).use { o -> f.inputStream().use { it.copyTo(o) }; s.fsync(o) }
            }
            val intent = PendingIntent.getBroadcast(
                ctx, id, Intent(ctx, InstallReceiver::class.java),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            s.commit(intent.intentSender)
        }
    }

    /** حفظ النسخة في مجلد التنزيلات */
    fun saveToDownloads(ctx: Context, f: File, name: String): Boolean {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/APK-Workshop")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        return true
    }
}
