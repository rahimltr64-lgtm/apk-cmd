package com.rahim.apkcmd

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF0F7B5F)
private val GreenLight = Color(0xFFE3F4EC)

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Green, onPrimary = Color.White, primaryContainer = GreenLight,
                    background = Color.White, surface = Color.White, surfaceVariant = GreenLight
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize(), color = Color.White) { Screen(vm) }
                }
            }
        }
    }
}

@Composable
private fun Screen(vm: AppVm) {
    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::openApk) }
    val pickAttach = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::attach) }
    val list = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    LaunchedEffect(vm.msgs.size, vm.pending) { if (vm.msgs.isNotEmpty()) list.animateScrollToItem(vm.msgs.size) }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        // الشريط العلوي
        Row(Modifier.fillMaxWidth().background(Green).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ورشة APK", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(vm.project?.name ?: "لم يُختر ملف", color = Color.White.copy(alpha = .8f), fontSize = 12.sp, maxLines = 1)
            }
            TextButton(onClick = { pickApk.launch(arrayOf("*/*")) }, enabled = !vm.busy) { Text("اختيار APK", color = Color.White) }
            TextButton(onClick = { vm.showHistory = true }, enabled = vm.project != null) { Text("النسخ", color = Color.White) }
            TextButton(onClick = { vm.showSettings = true }) { Text("⚙️", color = Color.White) }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Spacer(Modifier.height(4.dp)) }
            items(vm.msgs) { m ->
                val mine = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (mine) Green else GreenLight,
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Text(m.text, Modifier.padding(10.dp), color = if (mine) Color.White else Color(0xFF12332A), fontSize = 15.sp)
                    }
                }
            }
            vm.pending?.let { pd ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), border = androidx.compose.foundation.BorderStroke(1.dp, Green)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("معاينة التغييرات", fontWeight = FontWeight.Bold, color = Green)
                            pd.preview.forEach { Text(it, fontSize = 14.sp) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = vm::confirm, enabled = !vm.busy) { Text("تنفيذ") }
                                OutlinedButton(onClick = vm::cancelPending) { Text("إلغاء") }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(4.dp)) }
        }

        if (vm.busy && vm.logs.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().background(Color(0xFFF4F8F6)).padding(10.dp)) {
                LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth(), color = Green)
                Spacer(Modifier.height(4.dp))
                vm.logs.takeLast(4).forEach { Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace, maxLines = 1) }
            }
        } else if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)

        vm.attachName?.let {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("📎 $it", Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                TextButton(onClick = vm::clearAttach) { Text("إزالة") }
            }
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { pickAttach.launch(arrayOf("*/*")) }) { Text("📎") }
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("اكتب أمرك… مثال: غيّر الأيقونة") }, maxLines = 4
            )
            Spacer(Modifier.width(6.dp))
            Button(onClick = { vm.send(text); text = "" }, enabled = !vm.busy && text.isNotBlank()) { Text("إرسال") }
        }
    }

    if (vm.showSettings) {
        var k by remember { mutableStateOf(vm.apiKey) }
        var m by remember { mutableStateOf(vm.model) }
        AlertDialog(
            onDismissRequest = { vm.showSettings = false },
            title = { Text("الإعدادات") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(k, { k = it }, label = { Text("مفتاح Claude API") }, singleLine = true)
                    OutlinedTextField(m, { m = it }, label = { Text("اسم النموذج") }, singleLine = true)
                    Text("المفتاح يُحفظ على هاتفك فقط.", fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.saveSettings(k, m) }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { vm.showSettings = false }) { Text("إغلاق") } }
        )
    }

    if (vm.showHistory) {
        val fmt = remember { SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()) }
        AlertDialog(
            onDismissRequest = { vm.showHistory = false },
            title = { Text("النسخ") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vm.versions.reversed()) { v ->
                        Column {
                            Text("النسخة ${v.n} • ${fmt.format(Date(v.time))}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(v.label, fontSize = 13.sp, maxLines = 2)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(onClick = { vm.install(v) }) { Text("تثبيت") }
                                TextButton(onClick = { vm.save(v) }) { Text("حفظ") }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.undo() }, enabled = vm.versions.size > 1) { Text("↩️ تراجع عن الأخيرة") } },
            dismissButton = { TextButton(onClick = { vm.showHistory = false }) { Text("إغلاق") } }
        )
    }
}
