package com.rahim.apkcmd

import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** إعادة بناء الـ ZIP: تغيير أسماء/محتوى ملفات + إزالة التوقيع القديم + محاذاة (zipalign). */
object ZipTool {
    private class Counting(o: OutputStream) : FilterOutputStream(o) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private fun isOldSignature(n: String) = n.startsWith("META-INF/") &&
        (n == "META-INF/MANIFEST.MF" || n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC"))

    fun rebuild(
        input: File, output: File,
        renames: Map<String, String> = emptyMap(),
        replacements: Map<String, ByteArray> = emptyMap(),
        progress: (Float) -> Unit = {}
    ) {
        ZipFile(input).use { zf ->
            val entries = zf.entries().asSequence().filter { !it.isDirectory && !isOldSignature(it.name) }.toList()
            val cnt = Counting(FileOutputStream(output).buffered())
            ZipOutputStream(cnt).use { zo ->
                entries.forEachIndexed { i, e ->
                    val data = replacements[e.name] ?: zf.getInputStream(e).use { it.readBytes() }
                    val outName = renames[e.name] ?: e.name
                    val stored = e.method == ZipEntry.STORED || e.name == "resources.arsc"
                    val ze = ZipEntry(outName)
                    if (stored) {
                        ze.method = ZipEntry.STORED
                        ze.size = data.size.toLong(); ze.compressedSize = data.size.toLong()
                        ze.crc = java.util.zip.CRC32().also { it.update(data) }.value
                        val align = if (outName.endsWith(".so")) 4096 else 4
                        val offset = cnt.count + 30 + outName.toByteArray(Charsets.UTF_8).size
                        val pad = ((align - (offset % align)) % align).toInt()
                        if (pad > 0) ze.extra = ByteArray(pad)
                    } else ze.method = ZipEntry.DEFLATED
                    zo.putNextEntry(ze); zo.write(data); zo.closeEntry()
                    progress((i + 1f) / entries.size)
                }
            }
        }
    }
}
