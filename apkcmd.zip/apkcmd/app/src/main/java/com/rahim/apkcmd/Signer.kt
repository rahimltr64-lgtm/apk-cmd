package com.rahim.apkcmd

import android.content.Context
import com.android.apksig.ApkSigner
import org.spongycastle.asn1.x500.X500Name
import org.spongycastle.cert.jcajce.JcaX509CertificateConverter
import org.spongycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.spongycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** مفتاح توقيع واحد يُنشأ تلقائيًا ويُعاد استعماله حتى تُثبَّت النسخ الجديدة فوق القديمة. */
object Signer {
    private fun load(ctx: Context): Pair<PrivateKey, X509Certificate> {
        val kf = File(ctx.filesDir, "sign.pk8"); val cf = File(ctx.filesDir, "sign.der")
        if (!kf.exists() || !cf.exists()) {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=APK Workshop")
            val now = System.currentTimeMillis()
            val b = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), Date(now - 86_400_000L),
                Date(now + 30L * 365 * 86_400_000L), name, kp.public
            )
            val holder = b.build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
            val cert = JcaX509CertificateConverter().getCertificate(holder)
            kf.writeBytes(kp.private.encoded); cf.writeBytes(cert.encoded)
        }
        val pk = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
        val cert = cf.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) } as X509Certificate
        return pk to cert
    }

    fun sign(ctx: Context, input: File, output: File) {
        val (pk, cert) = load(ctx)
        val cfg = ApkSigner.SignerConfig.Builder("apkcmd", pk, listOf(cert)).build()
        output.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(input).setOutputApk(output)
            .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true)
            .build().sign()
    }
}
