package com.rahim.apkcmd

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import com.reandroid.apk.ApkModule
import com.reandroid.arsc.chunk.xml.AndroidManifestBlock
import com.reandroid.arsc.chunk.xml.ResXmlElement
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class Act(val type: String, val a: JSONObject) {
    fun s(k: String) = a.optString(k, "").trim()
}

class Job(val acts: List<Act>, val attach: ByteArray?, val attachName: String?)

class AppInfo(
    val pkg: String, val vName: String, val vCode: Int,
    val perms: List<String>, val activities: List<Pair<String, Boolean>>
)

/**
 * كل استدعاءات مكتبة ARSCLib (تعديل AndroidManifest و resources.arsc) محصورة في هذا الكائن.
 */
object Arsc {
    private const val ID_NAME = 0x01010003
    private const val ID_LABEL = 0x01010001
    private const val ID_AUTHORITIES = 0x01010018
    private const val ID_TARGET_ACTIVITY = 0x01010202

    private fun ResXmlElement.attr(id: Int): String? = searchAttributeByResourceId(id)?.valueAsString

    private fun isLauncher(act: ResXmlElement) =
        act.listElements("intent-filter").any { f ->
            f.listElements("category").any { it.attr(ID_NAME) == "android.intent.category.LAUNCHER" }
        }

    fun info(apk: File): AppInfo = ApkModule.loadApkFile(apk).use { m ->
        val mf = m.androidManifest
        val perms = mf.manifestElement.listElements("uses-permission").mapNotNull { it.attr(ID_NAME) }
        val acts = mf.applicationElement?.listElements("activity")
            ?.mapNotNull { e -> e.attr(ID_NAME)?.let { it to isLauncher(e) } } ?: emptyList()
        AppInfo(mf.packageName ?: "", mf.versionName ?: "", mf.versionCode ?: 0, perms, acts)
    }

    private fun removeByName(parent: ResXmlElement, tag: String, name: String): Int {
        var n = 0
        for (e in parent.listElements(tag).toList()) if (e.attr(ID_NAME) == name) { parent.removeElement(e); n++ }
        return n
    }

    private fun renamePackage(mf: AndroidManifestBlock, newPkg: String) {
        val old = mf.packageName ?: return
        val app = mf.applicationElement
        fun fq(v: String) = when {
            v.startsWith(".") -> old + v
            !v.contains(".") -> "$old.$v"
            else -> v
        }
        fun fix(el: ResXmlElement, id: Int, f: (String) -> String) {
            val a = el.searchAttributeByResourceId(id) ?: return
            val s = a.valueAsString ?: return
            val n = f(s)
            if (n != s) a.setValueAsString(n)
        }
        if (app != null) {
            fix(app, ID_NAME) { fq(it) }
            for (tag in listOf("activity", "service", "receiver", "provider", "activity-alias")) {
                for (e in app.listElements(tag)) {
                    fix(e, ID_NAME) { fq(it) }
                    if (tag == "activity-alias") fix(e, ID_TARGET_ACTIVITY) { fq(it) }
                    if (tag == "provider") fix(e, ID_AUTHORITIES) { it.replace(old, newPkg) }
                }
            }
        }
        for (tag in listOf("uses-permission", "permission")) {
            for (e in mf.manifestElement.listElements(tag)) {
                fix(e, ID_NAME) { if (it.startsWith("$old.")) newPkg + it.substring(old.length) else it }
            }
        }
        mf.setPackageName(newPkg)
    }

    /** يعدّل الـ manifest والجداول ويكتب ملفًا جديدًا. يعيد versionCode النهائي. */
    fun edit(
        input: File, output: File, acts: List<Act>, isBase: Boolean,
        poolRenames: Map<String, String>, forcedCode: Int?
    ): Int = ApkModule.loadApkFile(input).use { m ->
        val mf = m.androidManifest
        var code = forcedCode
        acts.firstOrNull { it.type == "set_version" }?.let { a ->
            if (code == null) a.a.optInt("code", 0).takeIf { it > 0 }?.let { code = it }
            if (isBase) a.s("name").takeIf { it.isNotEmpty() }?.let { mf.setVersionName(it) }
        }
        val newCode = code ?: ((mf.versionCode ?: 0) + 1)
        mf.setVersionCode(newCode)

        for (a in acts) {
            when (a.type) {
                "set_package_name" -> if (a.s("package").isNotEmpty()) renamePackage(mf, a.s("package"))
                "set_app_name" -> if (isBase) {
                    mf.setApplicationLabel(a.s("name"))
                    mf.applicationElement?.listElements("activity")?.filter { isLauncher(it) }?.forEach { act ->
                        act.searchAttributeByResourceId(ID_LABEL)?.setValueAsString(a.s("name"))
                    }
                }
                "add_permission" -> if (isBase) {
                    val p = a.s("permission")
                    val has = mf.manifestElement.listElements("uses-permission").any { it.attr(ID_NAME) == p }
                    if (p.isNotEmpty() && !has) mf.addUsesPermission(p)
                }
                "remove_permission" -> if (isBase) removeByName(mf.manifestElement, "uses-permission", a.s("permission"))
                "remove_activity" -> if (isBase) {
                    val app = mf.applicationElement
                    val want = a.s("name")
                    if (app != null) for (e in app.listElements("activity").toList()) {
                        val n = e.attr(ID_NAME) ?: continue
                        if (n == want || n.endsWith(want) || want.endsWith(n)) {
                            if (isLauncher(e)) throw IllegalStateException("لا يمكن حذف النشاط الرئيسي: $n")
                            app.removeElement(e)
                        }
                    }
                }
                "replace_text" -> if (isBase && m.hasTableBlock()) {
                    val find = a.s("find")
                    if (find.isNotEmpty()) {
                        for (s in m.tableBlock.tableStringPool) {
                            val v = s.get() ?: continue
                            if (!v.startsWith("res/") && v.contains(find)) runCatching { s.set(v.replace(find, a.a.optString("replace", ""))) }
                        }
                    }
                }
            }
        }
        if (isBase && poolRenames.isNotEmpty() && m.hasTableBlock()) {
            for (s in m.tableBlock.tableStringPool) {
                val v = s.get() ?: continue
                poolRenames[v]?.let { s.set(it) }
            }
        }
        m.writeApk(output)
        newCode
    }
}

object Engine {
    private val SKIP = setOf("AndroidManifest.xml", "resources.arsc")

    private fun names(f: File): List<String> =
        ZipFile(f).use { z -> z.entries().asSequence().filter { !it.isDirectory }.map { it.name }.toList() }

    private fun isImg(n: String) = listOf(".png", ".jpg", ".jpeg", ".webp").any { n.endsWith(it, true) }

    fun iconTargets(files: List<String>, hint: String): List<String> {
        val h = hint.lowercase()
        return files.filter { n ->
            n.startsWith("res/") && run {
                val base = n.substringAfterLast('/').substringBeforeLast('.').lowercase()
                (base.startsWith("ic_launcher") || (h.isNotEmpty() && base.contains(h))) &&
                    (n.endsWith(".png", true) || n.endsWith(".webp", true) || n.endsWith(".xml", true))
            }
        }
    }

    fun fileTargets(files: List<String>, contains: String, ext: String): List<String> {
        if (contains.isEmpty()) return emptyList()
        return files.filter { n ->
            n !in SKIP && !n.startsWith("META-INF/") && !n.endsWith(".dex") &&
                n.contains(contains, true) && (ext.isEmpty() || n.endsWith(".$ext", true))
        }
    }

    /** وصف عربي لما سيحدث فعلًا قبل التنفيذ */
    fun preview(file: File, kind: String, ctx: Context, job: Job): List<String> {
        val base = baseOf(ctx, file, kind)
        val files = names(base)
        val out = mutableListOf<String>()
        for (a in job.acts) when (a.type) {
            "change_icon" -> {
                val t = iconTargets(files, a.s("name_hint"))
                out += when {
                    job.attach == null || BitmapFactory.decodeByteArray(job.attach, 0, job.attach.size) == null ->
                        "⚠️ الأيقونة: لا توجد صورة مرفقة صالحة"
                    t.isEmpty() -> "⚠️ الأيقونة: لم أجد ملفات الأيقونة (ربما أسماؤها مشفّرة)"
                    else -> "🖼️ الأيقونة: سيتم استبدال ${t.size} ملف"
                }
            }
            "replace_file" -> {
                val t = fileTargets(files, a.s("path_contains"), a.s("ext"))
                out += when {
                    job.attach == null -> "⚠️ استبدال ملف: لا يوجد ملف مرفق"
                    t.isEmpty() -> "⚠️ استبدال ملف: لا ملفات تطابق «${a.s("path_contains")}»"
                    else -> "📁 استبدال ${t.size} ملف: " + t.take(4).joinToString("، ") { it.substringAfterLast('/') } + if (t.size > 4) "…" else ""
                }
            }
            "set_app_name" -> out += "✏️ اسم التطبيق ← ${a.s("name")}"
            "set_package_name" -> out += "📦 اسم الحزمة ← ${a.s("package")}"
            "set_version" -> out += "🔢 رقم الإصدار ← ${a.a.optInt("code", 0).takeIf { it > 0 } ?: "+1"} ${a.s("name")}"
            "add_permission" -> out += "➕ صلاحية: ${a.s("permission")}"
            "remove_permission" -> out += "➖ صلاحية: ${a.s("permission")}"
            "replace_text" -> out += "🔤 «${a.s("find")}» ← «${a.a.optString("replace")}»"
            "remove_activity" -> out += "🗑️ حذف النافذة: ${a.s("name")}"
            else -> out += "⚠️ أمر غير معروف: ${a.type}"
        }
        return out
    }

    fun info(ctx: Context, file: File, kind: String): AppInfo = Arsc.info(baseOf(ctx, file, kind))

    private fun isBaseName(n: String) = n.endsWith("base.apk") || n.contains("base-master")

    /** ملف APK الرئيسي (للـ apks يُستخرج الأساسي إلى الكاش) */
    fun baseOf(ctx: Context, file: File, kind: String): File {
        if (kind != "apks") return file
        val out = File(ctx.cacheDir, "base_${file.parentFile?.name}.apk")
        if (out.exists() && out.lastModified() >= file.lastModified()) return out
        ZipFile(file).use { z ->
            val apks = z.entries().asSequence().filter { it.name.endsWith(".apk") }.toList()
            val b = apks.firstOrNull { isBaseName(it.name) } ?: apks.maxByOrNull { it.size }
                ?: throw Exception("لا يوجد ملف apk داخل الحزمة")
            z.getInputStream(b).use { i -> out.outputStream().use { i.copyTo(it) } }
        }
        return out
    }

    // ---------- بناء النسخة الجديدة ----------

    private fun squareBitmap(src: Bitmap, size: Int, round: Boolean): Bitmap {
        val s = minOf(src.width, src.height)
        val crop = Bitmap.createBitmap(src, (src.width - s) / 2, (src.height - s) / 2, s, s)
        val scaled = Bitmap.createScaledBitmap(crop, size, size, true)
        if (!round) return scaled
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.clipPath(Path().apply { addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW) })
        c.drawBitmap(scaled, 0f, 0f, p)
        return out
    }

    private fun encode(b: Bitmap, name: String): ByteArray {
        val o = ByteArrayOutputStream()
        when {
            name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> b.compress(Bitmap.CompressFormat.JPEG, 92, o)
            name.endsWith(".webp", true) -> @Suppress("DEPRECATION") b.compress(Bitmap.CompressFormat.WEBP, 95, o)
            else -> b.compress(Bitmap.CompressFormat.PNG, 100, o)
        }
        return o.toByteArray()
    }

    private fun iconSize(path: String) = when {
        "mdpi" in path -> 48; "hdpi" in path && "xhdpi" !in path && "xxhdpi" !in path -> 72
        "xxxhdpi" in path -> 192; "xxhdpi" in path -> 144; "xhdpi" in path -> 96
        else -> 192
    }

    private fun zipSize(f: File, name: String): Pair<Int, Int>? = try {
        ZipFile(f).use { z ->
            val e = z.getEntry(name) ?: return null
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            z.getInputStream(e).use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth > 0) o.outWidth to o.outHeight else null
        }
    } catch (e: Exception) { null }

    /** بناء + محاذاة + توقيع لملف APK واحد. يعيد versionCode المستعمل. */
    private fun buildApk(
        ctx: Context, input: File, output: File, job: Job, isBase: Boolean, forcedCode: Int?,
        log: (String) -> Unit, prog: (Float) -> Unit
    ): Int {
        val files = names(input)
        val renames = mutableMapOf<String, String>()
        val repl = mutableMapOf<String, ByteArray>()
        if (isBase) for (a in job.acts) {
            if (a.type == "change_icon" && job.attach != null) {
                val src = BitmapFactory.decodeByteArray(job.attach, 0, job.attach.size)
                    ?: throw Exception("صورة الأيقونة غير صالحة")
                val t = iconTargets(files, a.s("name_hint"))
                if (t.isEmpty()) throw Exception("لم أجد ملفات الأيقونة داخل التطبيق")
                for (p in t) {
                    val newPath = if (p.endsWith(".xml")) p.removeSuffix(".xml") + ".png" else p
                    if (newPath != p) renames[p] = newPath
                    repl[p] = encode(squareBitmap(src, iconSize(p), p.contains("round", true)), newPath)
                }
                log("الأيقونة: ${t.size} ملف")
            }
            if (a.type == "replace_file" && job.attach != null) {
                val t = fileTargets(files, a.s("path_contains"), a.s("ext"))
                if (t.isEmpty()) throw Exception("لا ملفات تطابق «${a.s("path_contains")}»")
                val bmp = if (isImg(t[0])) BitmapFactory.decodeByteArray(job.attach, 0, job.attach.size) else null
                for (p in t) {
                    repl[p] = if (bmp != null && isImg(p)) {
                        val wh = zipSize(input, p)
                        encode(if (wh != null) Bitmap.createScaledBitmap(bmp, wh.first, wh.second, true) else bmp, p)
                    } else job.attach
                }
                log("استبدال ${t.size} ملف")
            }
        }
        val t1 = File(ctx.cacheDir, "s1_${System.nanoTime()}.apk")
        val t2 = File(ctx.cacheDir, "s2_${System.nanoTime()}.apk")
        try {
            log("تعديل AndroidManifest والموارد…"); prog(0.15f)
            val code = Arsc.edit(input, t1, job.acts, isBase, renames.filterKeys { it.endsWith(".xml") }
                .entries.associate { it.key to it.value }, forcedCode)
            log("إعادة التجميع والمحاذاة…")
            ZipTool.rebuild(t1, t2, renames, repl) { prog(0.3f + 0.4f * it) }
            log("التوقيع…"); prog(0.8f)
            Signer.sign(ctx, t2, output)
            return code
        } finally { t1.delete(); t2.delete() }
    }

    /** بناء نسخة جديدة (apk أو apks) */
    fun build(ctx: Context, input: File, output: File, kind: String, job: Job, log: (String) -> Unit, prog: (Float) -> Unit) {
        if (kind != "apks") {
            val c = buildApk(ctx, input, output, job, true, null, log, prog)
            log("versionCode = $c"); prog(1f); return
        }
        val work = File(ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
        try {
            ZipFile(input).use { z ->
                val apks = z.entries().asSequence().filter { it.name.endsWith(".apk") }.toList()
                val baseE = apks.firstOrNull { isBaseName(it.name) } ?: apks.maxByOrNull { it.size }
                    ?: throw Exception("لا يوجد apk داخل الحزمة")
                val done = HashMap<String, File>()
                var code: Int? = null
                val ordered = listOf(baseE) + apks.filter { it !== baseE }
                ordered.forEachIndexed { i, e ->
                    log("معالجة ${e.name}")
                    val src = File(work, "in_$i.apk"); val dst = File(work, "out_$i.apk")
                    z.getInputStream(e).use { s -> src.outputStream().use { s.copyTo(it) } }
                    val c = buildApk(ctx, src, dst, job, e === baseE, code, log) { prog((i + it) / ordered.size) }
                    if (e === baseE) code = c
                    done[e.name] = dst; src.delete()
                }
                ZipOutputStream(output.outputStream().buffered()).use { zo ->
                    z.entries().asSequence().forEach { e ->
                        if (e.isDirectory) return@forEach
                        zo.putNextEntry(ZipEntry(e.name))
                        val f = done[e.name]
                        if (f != null) f.inputStream().use { it.copyTo(zo) } else z.getInputStream(e).use { it.copyTo(zo) }
                        zo.closeEntry()
                    }
                }
            }
        } finally { work.deleteRecursively() }
        prog(1f)
    }
}
