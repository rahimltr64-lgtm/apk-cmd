package com.rahim.apkcmd

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Msg(val role: String, val text: String)          // role: user | bot
class Pending(val plan: Plan, val preview: List<String>, val command: String)

class AppVm(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("p", 0)

    val msgs = mutableStateListOf<Msg>()
    val logs = mutableStateListOf<String>()
    val versions = mutableStateListOf<Ver>()
    var project by mutableStateOf<Project?>(null); private set
    var pending by mutableStateOf<Pending?>(null)
    var busy by mutableStateOf(false)
    var progress by mutableStateOf(0f)
    var attachName by mutableStateOf<String?>(null)
    var showHistory by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var apiKey by mutableStateOf(prefs.getString("key", "") ?: "")
    var model by mutableStateOf(prefs.getString("model", "claude-haiku-5-5") ?: "claude-haiku-5-5")
    private var attachBytes: ByteArray? = null

    init {
        Store.cleanup(ctx)
        Store.last(ctx)?.let { setProject(it) }
        say("bot", if (project == null) "أهلًا 👋 اضغط «اختيار APK» وحمّل ملف apk أو apks، ثم اكتب لي ما تريد تعديله بالعربية."
        else "تم استرجاع آخر مشروع: ${project!!.name} (النسخة ${project!!.latest().n}). اكتب أمرك.")
    }

    private fun say(role: String, t: String) { msgs.add(Msg(role, t)) }
    private fun log(s: String) { logs.add(s) }
    private fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    private fun setProject(p: Project) {
        project = p; versions.clear(); versions.addAll(p.versions)
    }

    fun saveSettings(k: String, m: String) {
        apiKey = k.trim(); model = m.trim().ifEmpty { "claude-haiku-5-5" }
        prefs.edit().putString("key", apiKey).putString("model", model).apply()
        showSettings = false
    }

    private fun queryName(u: Uri): String? =
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        }

    fun openApk(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            try {
                val name = queryName(uri) ?: "app.apk"
                val kind = when {
                    name.endsWith(".apks", true) -> "apks"
                    name.endsWith(".apk", true) -> "apk"
                    else -> throw Exception("الملف يجب أن يكون apk أو apks")
                }
                val p = Project.create(Store.root(ctx), name, kind)
                val f = File(p.dir, "v0.$kind")
                ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
                if (f.length() > 100L * 1024 * 1024) say("bot", "⚠️ الحجم أكبر من 100MB، قد تنفد الذاكرة.")
                val info = Engine.info(ctx, f, kind)
                p.versions += Ver(0, "النسخة الأصلية", f.name, System.currentTimeMillis()); p.save()
                setProject(p)
                say("bot", "تم تحميل «$name» ✅\nالحزمة: ${info.pkg}\nالإصدار: ${info.vName} (${info.vCode})\nالصلاحيات: ${info.perms.size} • النوافذ: ${info.activities.size}\n\nاكتب أمرك، مثال: «غيّر اسم التطبيق إلى مكتبتي».")
            } catch (e: Throwable) {
                say("bot", "❌ تعذّر تحميل الملف: ${e.message}")
            } finally { busy = false }
        }
    }

    fun attach(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                attachBytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                attachName = queryName(uri) ?: "ملف"
            } catch (e: Throwable) { toast("تعذّر قراءة الملف") }
        }
    }

    fun clearAttach() { attachBytes = null; attachName = null }

    private fun infoJson(p: Project): String {
        val i = Engine.info(ctx, p.fileOf(p.latest()), p.kind)
        val att = attachName?.let {
            JSONObject().put("name", it).put("is_image", Regex("\\.(png|jpe?g|webp)$", RegexOption.IGNORE_CASE).containsMatchIn(it))
        }
        return JSONObject()
            .put("package", i.pkg).put("versionName", i.vName).put("versionCode", i.vCode)
            .put("kind", p.kind)
            .put("permissions", JSONArray(i.perms))
            .put("activities", JSONArray(i.activities.map { JSONObject().put("name", it.first).put("launcher", it.second) }))
            .put("attachment", att ?: JSONObject.NULL)
            .toString()
    }

    fun send(text: String) {
        if (text.isBlank() || busy) return
        say("user", text)
        val p = project
        if (p == null) { say("bot", "اختر ملف APK أولًا."); return }
        if (apiKey.isBlank()) { say("bot", "أضف مفتاح Claude API من ⚙️ الإعدادات أولًا."); return }
        viewModelScope.launch(Dispatchers.IO) {
            busy = true; pending = null
            try {
                val plan = Claude.plan(apiKey, model, text, infoJson(p))
                val prev = Engine.preview(p.fileOf(p.latest()), p.kind, ctx, Job(plan.acts, attachBytes, attachName))
                say("bot", plan.explanation.ifBlank { "هذا ما فهمته من أمرك:" } +
                    if (plan.unsupported.isNotBlank()) "\n\n⚠️ غير مدعوم: ${plan.unsupported}" else "")
                if (plan.acts.isNotEmpty()) pending = Pending(plan, prev, text)
            } catch (e: Throwable) {
                say("bot", "❌ ${e.message}")
            } finally { busy = false }
        }
    }

    fun cancelPending() { pending = null; say("bot", "تم الإلغاء.") }

    fun confirm() {
        val p = project ?: return
        val pd = pending ?: return
        pending = null
        viewModelScope.launch(Dispatchers.IO) {
            busy = true; progress = 0f; logs.clear()
            val n = p.latest().n + 1
            val out = File(p.dir, "v$n.${p.kind}")
            try {
                Engine.build(ctx, p.fileOf(p.latest()), out, p.kind, Job(pd.plan.acts, attachBytes, attachName), { log(it) }, { progress = it })
                p.versions += Ver(n, pd.command, out.name, System.currentTimeMillis()); p.save()
                setProject(p)
                say("bot", "✅ تمّ بناء النسخة $n وتوقيعها. اضغط «النسخ» للتثبيت أو الحفظ، أو اكتب أمرًا آخر.")
                clearAttach()
            } catch (e: Throwable) {
                out.delete()
                say("bot", "❌ فشل البناء: ${e.message ?: e.javaClass.simpleName}\n(لم تتغيّر النسخة السابقة)")
            } finally { busy = false }
        }
    }

    fun undo() {
        val p = project ?: return
        if (busy) return
        if (p.versions.size <= 1) { toast("لا يوجد ما يُتراجع عنه"); return }
        val v = p.versions.removeAt(p.versions.size - 1)
        p.fileOf(v).delete(); p.save(); setProject(p)
        say("bot", "↩️ تم التراجع عن: «${v.label}»")
    }

    fun install(v: Ver) {
        val p = project ?: return
        try { Installer.install(ctx, p.fileOf(v), p.kind) } catch (e: Throwable) { toast("تعذّر التثبيت: ${e.message}") }
    }

    fun save(v: Ver) {
        val p = project ?: return
        val base = p.name.substringBeforeLast('.')
        val ok = try { Installer.saveToDownloads(ctx, p.fileOf(v), "${base}_v${v.n}.${p.kind}") } catch (e: Throwable) { false }
        toast(if (ok) "حُفظ في Download/APK-Workshop" else "تعذّر الحفظ")
    }
}
