package com.rahim.apkcmd

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Plan(val explanation: String, val acts: List<Act>, val unsupported: String)

object Claude {
    private const val SYSTEM = """You translate Arabic commands into structured edits for an Android APK editor.
The editor can ONLY edit the manifest and resources (no Java/Kotlin/smali code changes).
Reply with ONE JSON object only, no markdown, no extra text:
{"explanation":"short Arabic summary of what will be done","actions":[...],"unsupported":"Arabic text, empty if everything is supported"}

Allowed actions (type + args):
- {"type":"set_app_name","name":"..."}            change the app display name
- {"type":"set_package_name","package":"com.x.y"}  change applicationId/package
- {"type":"set_version","code":123,"name":"1.2"}   optional fields; the code is auto-incremented by 1 on every build anyway
- {"type":"change_icon","name_hint":""}            replace launcher icon with the attached image (name_hint optional file base name)
- {"type":"add_permission","permission":"android.permission.X"}     always the FULL permission name
- {"type":"remove_permission","permission":"android.permission.X"}  always the FULL permission name
- {"type":"replace_text","find":"...","replace":"..."}  replace text inside string resources (strings.xml values) only
- {"type":"remove_activity","name":"exact name from the app info"}  never the launcher activity
- {"type":"replace_file","path_contains":"ic_splash","ext":"png"}   replace resource/asset files (image, font, sound) with the attached file

Rules: use change_icon or replace_file only when attachment exists in the app info. If a request needs code changes
(removing ads in code, changing logic, deleting a screen that is started from code), put it in "unsupported" and
do not invent actions. Keep names exactly as given in the app info. Output Arabic for explanation/unsupported."""

    fun plan(key: String, model: String, command: String, info: String): Plan {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1000)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user")
                .put("content", "App info:\n$info\n\nCommand:\n$command")))
        val c = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
            setRequestProperty("content-type", "application/json")
            setRequestProperty("x-api-key", key)
            setRequestProperty("anthropic-version", "2023-06-01")
        }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (!ok) {
            val m = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(200) }
            throw Exception("خطأ من Claude (${c.responseCode}): $m")
        }
        val content = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) content.getJSONObject(i).optString("text").let { sb.append(it) }
        val raw = sb.toString()
        val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
        if (s < 0 || e < s) throw Exception("ردّ Claude غير مفهوم")
        val j = JSONObject(raw.substring(s, e + 1))
        val arr = j.optJSONArray("actions") ?: JSONArray()
        val acts = (0 until arr.length()).map { arr.getJSONObject(it) }.map { Act(it.optString("type"), it) }
        return Plan(j.optString("explanation"), acts, j.optString("unsupported"))
    }
}
